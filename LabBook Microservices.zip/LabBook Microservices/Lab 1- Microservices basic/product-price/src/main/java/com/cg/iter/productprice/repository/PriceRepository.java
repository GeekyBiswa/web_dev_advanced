package com.cg.iter.productprice.repository;

import org.springframework.data.repository.CrudRepository;

import com.cg.iter.productprice.entity.ProductPrice;

public interface PriceRepository extends CrudRepository<ProductPrice, Integer>{
//3rd step
}
