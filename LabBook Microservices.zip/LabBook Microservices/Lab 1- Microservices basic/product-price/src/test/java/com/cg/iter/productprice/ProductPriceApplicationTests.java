package com.cg.iter.productprice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductPriceApplicationTests {

	@Test
	void contextLoads() {
	}

}
