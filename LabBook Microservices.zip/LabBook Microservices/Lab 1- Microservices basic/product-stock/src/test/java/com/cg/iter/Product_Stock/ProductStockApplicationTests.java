package com.cg.iter.Product_Stock;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductStockApplicationTests {

	@Test
	void contextLoads() {
	}

}
